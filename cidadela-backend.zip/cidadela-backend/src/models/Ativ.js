const mongoose = require('mongoose');

const respostaSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId, // mongoose entende que o objeto se relaciona com outra tabela
        ref: 'User' // criado no User.js
    },
    nomeAluno: {
        type: String,
        required: true
    },
    timestamp: Number,
    resposta: {
        type: String,
        required: true
    }

});

const ativSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId, // mongoose entende que o objeto se relaciona com outra tabela
        ref: 'User' // criado no User.js
    },
    titulo: {
        type: String,
        required: true
    },
    disciplina: {
        type: String,
        required: true
    },
    descricao: {
        type: String,
        default: ''
    },
    dataEntrega: {
        type: String
    },
    respostas: [respostaSchema]
});

// Relaciona um modelo a partir do moongose ao mongoDB
mongoose.model('Ativ', ativSchema);