require('./models/User');
require('./models/Ativ');

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const ativRoutes = require('./routes/ativRoutes');
const requireAuth = require('./middlewares/requireAuth');

const app = express();

// bodyParser tem que vir antes do authRoutes
app.use(bodyParser.json());
app.use(authRoutes);
app.use(userRoutes);
app.use(ativRoutes);

const mongoUri = 'mongodb+srv://guilherme-couto:MONGOdb@cluster0.w9dcz.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
if(!mongoUri) {
    throw new Error(`Invalid mongoUri`);
}

mongoose.connect(mongoUri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

mongoose.connection.on('connected', () => {
    console.log('Conectado ao mongo');
});
mongoose.connection.on('error', err => {
    console.error('Erro em conectar ao mongo', err);
});

app.get('/', requireAuth, (req, res) => {
    res.send(`Seu email: ${req.user.email}`);
});

app.listen(3000, () => {
    console.log('Listening on port 3000');
});