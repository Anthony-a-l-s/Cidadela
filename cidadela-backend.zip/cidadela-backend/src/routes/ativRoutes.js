const express = require('express');
const mongoose = require('mongoose');
const requireAuth = require('../middlewares/requireAuth'); // Para ter certeza que a pessoa está logada

const Ativ = mongoose.model('Ativ');

const router = express.Router();

router.use(requireAuth); // Exige que o usuario esteja logado

// Para CONSULTAR as atividades
router.get('/atividades', async (req, res) => {
    // Who the current user is
    const atividades = await Ativ.find({ userId: req.user._id });

    res.send(atividades);
});

// Para o user CRIAR uma track
router.post('/atividades', async (req, res) => {
    const { titulo, disciplina, descricao, dataEntrega } = req.body;

    if (!titulo || !disciplina || !descricao || !dataEntrega) {
        return res.status(422).send({ error: 'É preciso informar Titulo, Disciplina, Descricao e a Data de Entrega' });
    }

    try {
        const atividade = new Ativ({ titulo, disciplina, descricao, dataEntrega, userId: req.user._id });
        await atividade.save(); // Para salvar no banco de dados
        res.send(atividade);
    } catch (err) {
        res.status(422).send({ error: err.message });
    }
});

module.exports = router;