const express = require('express');
const mongoose = require('mongoose');
const requireAuth = require('../middlewares/requireAuth'); // Para ter certeza que a pessoa está logada

const User = mongoose.model('User');

const router = express.Router();

router.use(requireAuth); // Exige que o usuario esteja logado

// Para CONSULTAR as atividades
router.get('/users', async (req, res) => {
    // Who the current user is
    const users = await User.find({ userId: req.user._id });

    res.send(users);
});

module.exports = router;