const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = mongoose.model('User');

const router = express.Router();

// when someone tries to signup
router.post('/signup', async (req, res) => {
    const { email, password, name, birthDate, phone, address } = req.body;

    try {
        const user = new User({ email, password, name, birthDate, phone, address });
        await user.save(); // conecta e salva na internet

        const token = jwt.sign({ userId: user._id }, 'MY_SECRET_KEY');
        res.send({ token });
    } catch (err) {
        return res.status(422).send(err.message);
    }
});

router.post('/signin', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(422).send({ error: 'É preciso informar email e senha' });
    }

    const user = await User.findOne({ email });
    if (!user) {
        return res.status(422).send({ error: 'Email e/ou senha inválidos' });
    }

    try {
        await user.comparePassword(password);
        const token = jwt.sign({ userId: user._id }, 'MY_SECRET_KEY');
        res.send({ token });
    } catch (err) {
        return res.status(422).send({ error: 'Senha e/ou email inválidos' });
    }
});

module.exports = router;